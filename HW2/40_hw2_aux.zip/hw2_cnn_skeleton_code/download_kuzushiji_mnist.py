#!/usr/bin/env python

import utils

if __name__ == "__main__":
    utils.fetch_classification_data("Kuzushiji-MNIST")
