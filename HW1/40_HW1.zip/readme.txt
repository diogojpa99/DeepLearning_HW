This archive contains everything you need to complete Homework 1. It contains
the following files:

download_kuzushiji_mnist.py
- allows you to download the Kuzushiji-MNIST dataset to a compressed .npz file,
  which hw1-q2.py and hw1-q3.py can load.

hw1-q1.py
- contains skeleton code for Question 1, which covers classification with
  the perception, logistic regression, and the multi-layer perceptron, with
  implementation in numpy.

hw1-q2.py
- contains skeleton code for Question 2, which covers classification with
  logistic regression and the multi-layer perceptron, with implementation in
  torch.
